# 幻想乡｜初代家园可用美术资源包 v1.0

**这是已拆分的独立透明 PNG 资源，不是整张合成效果图。**

- `art/ui/`：16 个独立 RGBA 木纹 UI 纹理（上午/黄昏按钮四态、木牌、信息栏、羊皮纸、太阳/月亮/信息图标），**不把文字烘焙进图片**。用 Godot 中文字体渲染真实可读文字。
- `art/objects/`：12 个原创原生像素场景物件（**树桩三态**、倒木、石桌、路灯、栅栏、花丛、石头、小船、草丛）。包含透明 `props_atlas_256x192.png` 和 JSON atlas 坐标。
- `art/tiles/`：草地 / 深草 / 泥土 / 石径 / 河水五种 16×16 像素贴片。是局部材质起点，**不宣称已经组成完整可无缝拼接的大地图**。
- `art/characters/`：**原创中性测试居民** `test_woodland_bot`，24×32 四方向站立图；无蓝发/翅膀/琪露诺素材，无角色 AI 决策。
- `scripts/fantasia_ui_skin.gd`：Godot 4.6 风格脚本，把现有 Button 换成木质状态按钮，不改变点击逻辑或居民权限。
- `scripts/INTEGRATE_WITH_PUBLIC_VIEWER.gd.txt`：将木按钮与**视觉树桩**接到当前 `public_viewer.gd` 的最小改动示例。
- `manifest.json`：所有资产尺寸、脚底锚点、精灵图坐标。
- `previews/`：画册用于检查；**不要直接当美术资产导入 Godot**。

## 如何用于 Godot 4.6

1. 下载并解压后，把此包的 **`art/` 图片文件夹**合并到最新 `prototype/ai-first-home` 的 `prototypes/gpt_zero_home/`。**Godot 分支中已经提交了 UI 风格脚本和可选接入点，不需要再修改网络代码**。如果你不方便更新 GitHub 分支，包内 `scripts/fantasia_ui_skin.gd` 可作为独立脚本使用。不要覆盖原有 `art/home_day.svg`、`art/home_dusk.svg`。
2. 最新 `scripts/public_viewer.gd` 已经在按钮创建后自动调用 `FantasiaSkin.install(day_button, dusk_button)`，并为标题牌调用 `skin_title()`；资源存在时使用木纹、资源缺失时保留旧皮肤。按钮的 `_set_time()` 行为保持不变。
3. 最新观察器已包含可选 `GardenStumpVisualOnly` 视觉精灵接入点：有 PNG 时会出现在场景的石桌附近。**目前只是可见环境物件，不增加 `fallen_log` 的服务端可达节点、碰撞、坐姿或 AI 意图。**
4. UI 游戏中建议保持 `texture_filter = NEAREST`（图标纹理）；中文使用已通过真机验收的 Noto Sans SC（不要把字体转换成图片文字）。
5. 运行 `godot --headless --path . --script res://tests/public_viewer_smoke.gd` 并重新导出 staging；在 Android 横竖屏真机验收，特别检查按钮文本、大小、点击状态和公开居民仍可见。

## 作品和版权

- 原创木纹 UI 素材来自专门生成的透明 UI 精灵图；自然物件和中性测试居民为本轮程序化原创像素绘制。
- **没有包含东方 Project 琪露诺或其他现有作品角色的素材**；之前效果图里的蓝发相似角色只用于不应继续采用的示意展示。
- 不含第三方字体文件。请沿用项目已获授权的中文字体与许可证。
- 若正式公开发布，仍应对生成素材进行人工相似度审查与质量复核。

## 开发范围

这一包直接可用的是 UI 状态纹理、场景小物件与基础地面材质。**大木屋、整片树林、河流分层、室内图层仍需逐件精绘并做 Godot 遮挡与碰撞**，不能从定稿大图无损切出，也没有伪称已完成整个游戏美术。
