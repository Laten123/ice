#!/usr/bin/env python3
"""Zero-dependency import preflight for the Fantasia RGBA sprite package."""
from pathlib import Path
import json
import struct

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
assets = manifest['assets']
assert len(assets) >= 38, f'Expected at least 38 individual assets, got {len(assets)}'
for name, entry in assets.items():
    filename = root / entry['file']
    if not filename.is_file():
        raise RuntimeError(f'Missing {name}: {filename}')
    data = filename.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n', f'Invalid PNG signature: {filename}'
    w, h = struct.unpack('>II', data[16:24])
    assert [w, h] == entry['size'], f'PNG size mismatch {name}: {w}x{h}'
    assert data[25] == 6, f'{filename} must be RGBA (PNG color type 6)'
# No borrowed anime character in the live export package.
for file in (root / 'art/characters').glob('*.png'):
    assert 'cirno' not in file.name.lower() and '琪露诺' not in file.name
print('FANTASIA_ART_OK:', len(assets), 'named PNG assets, RGBA + sizes verified')
