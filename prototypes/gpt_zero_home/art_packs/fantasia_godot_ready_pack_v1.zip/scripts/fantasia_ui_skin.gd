extends RefCounted
## Fantasia pixel UI kit. Use from public_viewer.gd AFTER buttons have been created.
## Original AI-first viewer logic, only public snapshots, is unaffected.

const BASE := "res://art/ui/"

static func has_skin() -> bool:
    return ResourceLoader.exists(BASE + "button_day_normal.png")

static func _box(path: String) -> StyleBoxTexture:
    var box := StyleBoxTexture.new()
    box.texture = load(BASE + path) as Texture2D
    # Keep corners intact while stretching the center of the wooden frame.
    box.texture_margin_left = 26.0
    box.texture_margin_right = 26.0
    box.texture_margin_top = 18.0
    box.texture_margin_bottom = 18.0
    box.content_margin_left = 12.0
    box.content_margin_right = 12.0
    box.content_margin_top = 9.0
    box.content_margin_bottom = 9.0
    return box

static func skin_button(button: Button, theme: String) -> void:
    if not has_skin():
        return
    var names := {
        "normal": "button_%s_normal.png" % theme,
        "hover": "button_%s_hover.png" % theme,
        "pressed": "button_%s_pressed.png" % theme,
        "disabled": "button_%s_disabled.png" % theme,
        "focus": "button_%s_hover.png" % theme,
    }
    for state in names:
        button.add_theme_stylebox_override(state, _box(names[state]))
    button.add_theme_color_override("font_color", Color("#fff2d2"))
    button.add_theme_color_override("font_hover_color", Color("#ffffff"))
    button.add_theme_color_override("font_pressed_color", Color("#fff4da"))
    button.add_theme_color_override("font_disabled_color", Color("#c1afa1"))
    button.add_theme_color_override("font_outline_color", Color("#452b28"))
    button.add_theme_constant_override("outline_size", 2)
    button.custom_minimum_size.x = maxf(button.custom_minimum_size.x, 152.0)

static func skin_title(header: PanelContainer) -> void:
    var title_texture := BASE + "title_floral.png"
    if not ResourceLoader.exists(title_texture):
        return
    var skin := StyleBoxTexture.new()
    skin.texture = load(title_texture) as Texture2D
    skin.texture_margin_left = 45.0
    skin.texture_margin_right = 45.0
    skin.texture_margin_top = 23.0
    skin.texture_margin_bottom = 23.0
    skin.content_margin_left = 14.0
    skin.content_margin_right = 14.0
    skin.content_margin_top = 10.0
    skin.content_margin_bottom = 10.0
    header.add_theme_stylebox_override("panel", skin)

static func install(day_button: Button, dusk_button: Button) -> void:
    skin_button(day_button, "day")
    skin_button(dusk_button, "dusk")
