#!/usr/bin/env python3
"""Safely copy the 2.5D module into a clone of the old Godot project.

Never modifies the current main scene, main.gd, Python V2 service, production
settings, or land rules. Requires an explicit target; refuses differing files.
"""
from __future__ import annotations
import argparse
import shutil
from pathlib import Path

BUNDLE = Path(__file__).resolve().parents[1]
PATHS = [
    "art/home_25d_exterior.png",
    "art/home_25d_interior.png",
    "scripts/first_home_25d.gd",
    "scripts/home_25d_points.gd",
    "scripts/home_25d_markers.gd",
    "scripts/home_25d_resident.gd",
    "scenes/first_home_25d.tscn",
    "scenes/first_home_25d_staging.tscn",
    "tests/first_home_25d_smoke.gd",
]

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target',type=Path,required=True,
                        help='isolated copy of prototypes/gpt_zero_home')
    parser.add_argument('--replace-25d-only',action='store_true',
                        help='replace only 25D module files; never modify other files')
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    target=args.target.resolve()
    assert target.is_dir() and (target/'project.godot').is_file(), 'Not a Godot project'
    assert target!=BUNDLE.resolve(), 'Do not install module into itself'
    changes=[]
    for rel in PATHS:
        source=BUNDLE/rel
        destination=target/rel
        assert source.is_file(),f'Missing required module file: {source}'
        if destination.exists():
            if destination.read_bytes()==source.read_bytes():
                print('[UNCHANGED]',rel)
                continue
            if not args.replace_25d_only:
                raise SystemExit('[REFUSE] Existing differing file: '+str(destination)+'; review it first')
        changes.append((source,destination,rel))
    for src,dst,rel in changes:
        if args.dry_run:
            print('[DRY RUN]',rel)
            continue
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)
        print('[COPIED]',rel)
    print('MODULE_READY: no default scene, server, credentials or production files changed')
    print('VIEW: godot --path',target,'res://scenes/first_home_25d.tscn')

if __name__=='__main__':
    main()
