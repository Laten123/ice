extends Node2D
## Only paints the currently confirmed public resident or an explicitly labeled test actor.
## Never sends a move/intent, generates AI responses, or reads private data.

var color_main := Color("#7d9cba")
var color_hair := Color("#433c55")
var display_activity := "stay"
var test_actor := false

func configure(test: bool, tint: Color = Color("#7d9cba"), hair: Color = Color("#433c55")) -> void:
    test_actor = test
    color_main = Color("#f2b958") if test else tint
    color_hair = Color("#71503b") if test else hair
    queue_redraw()

func set_activity(value: String) -> void:
    display_activity = value
    queue_redraw()

func _draw() -> void:
    # Feet anchor is (0,0) in ART pixel coordinates.
    var sitting := display_activity == "sit" or display_activity == "rest"
    var base_y: float = -31.0 if sitting else -40.0
    draw_ellipse_shadow()
    draw_rect(Rect2(-12, -4, 10, 4), Color("#474447"))
    draw_rect(Rect2(3, -4, 10, 4), Color("#474447"))
    if sitting:
        draw_rect(Rect2(-15, -15, 30, 13), color_main.darkened(0.16))
    else:
        draw_rect(Rect2(-12, -21, 24, 18), color_main.darkened(0.22))
    draw_rect(Rect2(-11, base_y + 12.0, 22, 15), color_main)
    draw_rect(Rect2(-8, base_y + 15.0, 12, 3), color_main.lightened(0.18))
    draw_rect(Rect2(-13, base_y + 5.0, 26, 14), Color("#e4b99b"))
    draw_rect(Rect2(-14, base_y, 28, 12), color_hair)
    draw_rect(Rect2(-12, base_y + 1, 12, 3), color_hair.lightened(0.14))
    draw_rect(Rect2(-7, base_y + 12, 3, 3), Color("#473534"))
    draw_rect(Rect2(5, base_y + 12, 3, 3), Color("#473534"))
    if display_activity == "read":
        draw_rect(Rect2(-2, -19, 18, 14), Color("#5f4737"))
        draw_rect(Rect2(0, -17, 7, 11), Color("#f0ddb5"))
        draw_rect(Rect2(8, -17, 6, 11), Color("#fff0c9"))
    if test_actor:
        draw_rect(Rect2(-18, base_y - 8, 36, 5), Color("#efc56e"))

func draw_ellipse_shadow() -> void:
    draw_circle(Vector2(0, 0), 13, Color(0.16, 0.26, 0.2, 0.25))
    draw_rect(Rect2(-16, -2, 32, 4), Color(0.15, 0.24, 0.2, 0.18))
